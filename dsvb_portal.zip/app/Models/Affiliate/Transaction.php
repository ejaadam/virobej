<?php

namespace App\Models\Affiliate;

use App\Models\BaseModel;
use DB;

class Transaction extends BaseModel
{
	 public function __construct ()
    {
         parent::__construct(); 
    }
	    
}