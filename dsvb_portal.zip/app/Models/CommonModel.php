<?php

namespace App\Models;
use DB;
use Illuminate\Database\Eloquent\Model;
use Config;
class CommonModel extends BaseModel
{
    public function __construct ()
    {
        parent::__construct();
    } 
	
    
	
}
